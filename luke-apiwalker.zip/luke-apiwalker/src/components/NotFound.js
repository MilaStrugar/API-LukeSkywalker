import React from 'react';
import PropTypes from 'prop-types';

const NotFound = () => {
    return (
        <div>
            <h1>These aren't the droids you are looking for</h1>
            <img src="https://tvline.com/wp-content/uploads/2019/08/ewan-mcgregor-star-wars-series.jpg?w=620" alt="" />
        </div>
    );
};


export default NotFound;